#!/bin/bash
echo "🔧 Installing Kernix Programming Language..."
echo "==========================================="

# Создание директорий
mkdir -p ~/.kernix/{bin,cache,stdlib,examples}

# Копирование конфигурации
cp .kernixrc ~/.kernixrc
echo "source ~/.kernixrc" >> ~/.zshrc

# Сборка компилятора
make clean
make -j$(nproc)

# Установка
make install

# Создание примеров
cat > ~/.kernix/examples/hello.kx << 'EOF'
// hello.kx - Hello World на Kernix
fn main() -> i32 {
    print("Hello, Kernix! 🚀");
    return 0;
}
EOF

cat > ~/.kernix/examples/filesystem.kx << 'EOF'
// filesystem.kx - Работа с файловой системой
fn main() -> i32 {
    // Создание файла
    let fd = open_file("test.txt", O_CREAT | O_WRONLY, 0o644);
    if fd < 0 {
        print("❌ Failed to create file");
        return 1;
    }
    
    // Запись в файл
    write_file(fd, "Hello from Kernix!", 18);
    close_file(fd);
    
    // Чтение из файла
    let fd2 = open_file("test.txt", O_RDONLY, 0);
    if fd2 >= 0 {
        let buffer[100];
        let bytes = read_file(fd2, buffer, 100);
        print("📖 Read from file: ");
        print(buffer);
        close_file(fd2);
    }
    
    // Удаление файла
    delete_file("test.txt");
    
    return 0;
}
EOF

echo "✅ Kernix installed successfully!"
echo "📁 Home: ~/.kernix"
echo "📚 Examples: ~/.kernix/examples"
echo "🚀 Usage: kernixc program.kx -o program"
echo "         ./program"
