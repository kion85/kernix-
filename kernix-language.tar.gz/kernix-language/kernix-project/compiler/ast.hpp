#pragma once
#include <vector>
#include <string>
#include <memory>
#include <llvm/IR/Value.h>

namespace llvm {
class Value;
class IRBuilder;
}

struct ASTNode {
    virtual ~ASTNode() = default;
    virtual llvm::Value* codegen(llvm::IRBuilder<>& builder) = 0;
};

struct SyscallNode : public ASTNode {
    std::string syscall_name;
    std::vector<std::unique_ptr<ASTNode>> args;
    
    llvm::Value* codegen(llvm::IRBuilder<>& builder) override;
};

struct NumberNode : public ASTNode {
    int value;
    llvm::Value* codegen(llvm::IRBuilder<>& builder) override;
};

struct StringNode : public ASTNode {
    std::string value;
    llvm::Value* codegen(llvm::IRBuilder<>& builder) override;
};
