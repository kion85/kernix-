#include "ast.hpp"
#include "syscalls.hpp"
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>

llvm::Value* SyscallNode::codegen(llvm::IRBuilder<>& builder) {
    std::vector<llvm::Value*> arg_values;
    for (auto& arg : args) {
        arg_values.push_back(arg->codegen(builder));
    }
    
    // Получаем функцию syscall из runtime
    llvm::Function* syscall_func = get_syscall_function(syscall_name, builder.GetInsertBlock()->getModule());
    return builder.CreateCall(syscall_func, arg_values);
}

llvm::Value* NumberNode::codegen(llvm::IRBuilder<>& builder) {
    return llvm::ConstantInt::get(builder.getInt32Ty(), value);
}
