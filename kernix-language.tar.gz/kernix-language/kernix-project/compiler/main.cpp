#include <iostream>
#include <fstream>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/IRBuilder.h>
#include "parser.tab.hpp"

extern FILE* yyin;
extern int yyparse();

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: kernixc <file.kx>" << std::endl;
        return 1;
    }
    
    yyin = fopen(argv[1], "r");
    if (!yyin) {
        std::cerr << "Cannot open file: " << argv[1] << std::endl;
        return 1;
    }
    
    // Парсинг
    yyparse();
    fclose(yyin);
    
    // Генерация кода
    llvm::LLVMContext context;
    llvm::Module module("kernix_module", context);
    llvm::IRBuilder<> builder(context);
    
    // Генерация main функции
    llvm::FunctionType* main_type = llvm::FunctionType::get(builder.getInt32Ty(), false);
    llvm::Function* main_func = llvm::Function::Create(main_type, llvm::Function::ExternalLinkage, "main", module);
    
    llvm::BasicBlock* entry_block = llvm::BasicBlock::Create(context, "entry", main_func);
    builder.SetInsertPoint(entry_block);
    
    // Здесь будет кодогенерация AST
    
    builder.CreateRet(llvm::ConstantInt::get(builder.getInt32Ty(), 0));
    
    // Вывод IR
    module.print(llvm::outs(), nullptr);
    
    return 0;
}
