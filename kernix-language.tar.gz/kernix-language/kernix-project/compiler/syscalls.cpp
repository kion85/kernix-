#include "syscalls.hpp"
#include <llvm/IR/Function.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/Module.h>

// Генерация функций для системных вызовов
llvm::Function* get_syscall_function(const std::string& name, llvm::Module* module) {
    llvm::IRBuilder<> builder(module->getContext());
    
    if (name == "spawn_process") {
        llvm::FunctionType* func_type = llvm::FunctionType::get(
            builder.getInt32Ty(), 
            {builder.getInt8PtrTy(), builder.getInt8PtrTy()}, 
            false
        );
        return llvm::Function::Create(func_type, llvm::Function::ExternalLinkage, "kernix_spawn_process", module);
    }
    // ... другие syscall функции
    return nullptr;
}
