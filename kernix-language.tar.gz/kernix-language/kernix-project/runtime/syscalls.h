#pragma once
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <sys/ioctl.h>
#include <semaphore.h>
#include <pthread.h>
#include <dirent.h>
#include <signal.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

// Process management
int kernix_spawn_process(const char* command, const char** args);
int kernix_fork_process();
int kernix_wait_for_process(int pid);
int kernix_terminate_process(int pid, int signal);
int kernix_get_process_info(int pid);
int kernix_set_process_priority(int pid, int priority);
int kernix_get_process_priority(int pid);
int kernix_get_memory_usage(int pid);
int kernix_get_cpu_usage();

// File operations
int kernix_open_file(const char* path, int mode, int permissions);
int kernix_close_file(int fd);
int kernix_write_file(int fd, const void* buffer, size_t size);
int kernix_read_file(int fd, void* buffer, size_t size);
int kernix_create_file(const char* path, int permissions);
int kernix_delete_file(const char* path);
int kernix_get_file_size(int fd);
int kernix_get_file_info(const char* path);
int kernix_copy_file(const char* source, const char* destination);
int kernix_move_file(const char* source, const char* destination);
int kernix_change_file_permissions(const char* path, int mode);
int kernix_check_file_existence(const char* path);
int kernix_sync_filesystem();
int kernix_flush_cache();

// Directory operations
int kernix_list_directory(const char* path);
int kernix_make_directory(const char* path, int mode);
int kernix_remove_directory(const char* path);
int kernix_change_directory(const char* path);
char* kernix_get_current_directory();

// Memory management
void* kernix_create_memory_region(size_t size);
int kernix_free_memory_region(void* ptr, size_t size);
void* kernix_allocate_memory(size_t size);
int kernix_free_memory(void* ptr);
int kernix_protect_memory(void* addr, size_t size, int prot);
int kernix_sync_memory(void* addr, size_t size, int flags);
void* kernix_allocate_shared(size_t size, const char* name);
int kernix_release_shared(const char* name);

// Network operations
int kernix_create_socket(int domain, int type, int protocol);
int kernix_bind_socket(int socket, const struct sockaddr* address, socklen_t address_len);
int kernix_listen_socket(int socket, int backlog);
int kernix_accept_connection(int socket, struct sockaddr* address, socklen_t* address_len);
int kernix_connect_socket(int socket, const struct sockaddr* address, socklen_t address_len);
int kernix_send_data(int socket, const void* buffer, size_t size, int flags);
int kernix_receive_data(int socket, void* buffer, size_t size, int flags);
int kernix_close_socket(int socket);
int kernix_set_socket_options(int socket, int level, int optname, const void* optval, socklen_t optlen);
int kernix_get_socket_options(int socket, int level, int optname, void* optval, socklen_t* optlen);

// Threading and synchronization
int kernix_fork_thread(void* (*func)(void*), void* arg);
int kernix_join_thread(pthread_t thread, void** retval);
int kernix_mutex_lock(pthread_mutex_t* mutex);
int kernix_mutex_unlock(pthread_mutex_t* mutex);
int kernix_semaphore_wait(sem_t* sem);
int kernix_semaphore_post(sem_t* sem);

// System information
int kernix_get_system_info(struct utsname* info);
int kernix_get_time(struct timeval* tv);
int kernix_set_time(const struct timeval* tv);
int kernix_sleep(unsigned int seconds);
int kernix_set_environment_variable(const char* key, const char* value);
char* kernix_get_environment_variable(const char* key);
int kernix_signal_handler(int signal, void (*handler)(int));
int kernix_pipe(int pipefd[2]);
int kernix_set_timer(int seconds);
int kernix_write_to_console(const char* text);

#ifdef __cplusplus
}
#endif
